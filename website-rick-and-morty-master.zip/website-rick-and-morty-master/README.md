# website-rick-and-morty
A simple website for a school course

Preview of the website can be found in the preview folder.

- [mobile screen](#mobile-screen)
- [large screen](#large-screen)

## large screen
![website for large screens](https://github.com/AshnaWiar/website-rick-and-morty/blob/master/preview/larg_screen.jpg?raw=true)

## mobile screen
![mobile screen website](https://github.com/AshnaWiar/website-rick-and-morty/blob/master/preview/mobile_screen.png?raw=true)
